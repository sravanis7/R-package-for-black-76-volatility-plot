#' Black76 
#' 
#'  Calculates and plots black76 volatility of a set of European options on future contracts
#'  @author Sravani Satpathy
#'  @param df
#'  @param date
#'  @param mode option
#'  @return the square of the input
#'  @export
plotImpliedVol <- function(df, date, option) {
  
  resultData = init(df, date, option)
  title = "Implied Volatility of Put & Call options VS Strike"
  if(option == "P") {
    resultData = resultData[which(results$type == "P"),]
    title = "Implied Volatility of Put option VS Strike"
  } else if(option == "C") {
    resultData = resultData[which(results$type == "C"),]
    title = "Implied Volatility of Call option VS Strike"
  }
  
  if(option != "CP") {
    ggplot(data=resultData, aes(x=strike,y=implied_volatility,colour=time_to_expiry,group=time_to_expiry)) +
      geom_line() +
      geom_point() +
      labs(title = title, x = "Strike", y = "Implied Volatility") +
      theme(legend.position="right",
            legend.key.size=unit(1.1, "cm"),
            text = element_text(color = "#c00000"),
            panel.background = element_rect(fill = '#444B5A'),
            panel.grid.minor = element_line(color = '#808080'),
            panel.grid.major = element_line(color = '#808080'),
            plot.title = element_text(size = 13),
            axis.title = element_text(size = 14, color = '#AA4371')) +
      scale_colour_gradient(name="Time To Expiry",low="red",high="white")
  } else {
    title = "Implied Volatility of Call vs Put option against Strike"
    ggplot(data=resultData, aes(x=strike,y=implied_volatility,colour=type)) +
      geom_line() +
      geom_point() +
      labs(title = title, x = "Strike", y = "Implied Volatility") +
      theme(legend.position="right",
            legend.key.size=unit(1.1, "cm"),
            text = element_text(color = "#c00000"),
            panel.background = element_rect(fill = '#444B5A'),
            panel.grid.minor = element_line(color = '#808080'),
            panel.grid.major = element_line(color = '#808080'),
            plot.title = element_text(size = 13),
            axis.title = element_text(size = 14, color = '#AA4371'))
  }
}


#' @param df
#' @param date
#' @param mode option
#' @export
init <- function(df, date, option){
  options("getSymbols.warning4.0"=FALSE)
  
  volatilities = vector(length=nrow(df))
  strikes = vector(length=nrow(df))
  types = vector(length=nrow(df))
  expiryTimeList = vector(length=nrow(df))
  optionPriceList = vector(length=nrow(df))
  futurePriceList = vector(length=nrow(df))
  
  # risk free rate based on specified date of 3month( US T-bill)
  getSymbols("DGS3MO", src = "FRED")
  r = as.data.frame(DGS3MO)[date, 1] / 100
  
  # for call option
  y_call <- function(v,fp,x,r,t,c) {
    d1 = (log(fp/x) + ((v*2)/2)*t) / (v*(t**0.5))
    d2 = d1 - v*(t**0.5)
    return (exp(-r*t) * (fp*pnorm(d1,0,1) - x*pnorm(d2,0,1)) - c)
  }
  
  # for put option
  y_put <- function(v,fp,x,r,t,p) {
    d1 = (log(fp/x) + ((v*2)/2)*t) / (v*(t**0.5))
    d2 = d1 - v*(t**0.5)
    return (exp(-r*t) * (x*pnorm(-d2,0,1) - fp*pnorm(-d1,0,1)) - p)
  }
  
  # get volatility v for each option
  for(i in 1:nrow(df)) {
    row = df[i,]
    fp = row$futurePrice
    x = row$strike
    t = row$time_to_expiry
    type = as.character(row$type)
    
    if(type == "C") {
      c = row$optionPrice
      implied_vol = uniroot(f=y_call,interval=c(0, 1),tol=0.0001,fp=fp,x=x,r=r,t=t,c=c)$root
      optionPriceList[i] = c
    } else {
      p = row$optionPrice
      implied_vol = uniroot(f=y_put,interval=c(0, 1),tol=0.0001,fp=fp,x=x,r=r,t=t,p=p)$root
      optionPriceList[i] = p
    }
    
    # return volatility and strike
    volatilities[i] = round(implied_vol, 3)
    strikes[i] = x
    types[i] = type
    expiryTimeList[i] = round(t, 3)
    futurePriceList[i] = round(fp, 3)
  }
  
  resultData = data.frame(strike=strikes, type=types, optionPrice=optionPriceList, futurePrice=futurePriceList, time_to_expiry=expiryTimeList, implied_volatility=volatilities)
  
  if(option == "P") {
    return (resultData[which(results$type == "P"),])
  } else if(option == "C") {
    return (resultData[which(results$type == "C"),])
  }
  return (resultData)
}